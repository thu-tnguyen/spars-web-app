$(function(){
    $('#searchInput').keyup(function(){
        $.ajax({
            type: "GET",
            url: '/browser/',
            data: {
                'search_text': $('#searchInput').val(),
            },
            success: searchSuccess,
            dataType: 'html'
        });
    });
});

function searchSuccess(data, textStatus, jqXHR)
{
    $('#search-results').html(data);
}