$(function(){
    $('#search').keyup(function(){
        $.ajax({
            type: "GET",
            url: '/browser/',
            data: {
                'search_text': $('#searchInput').val(),
                'csrfmiddlewaretoken': $('input[name=csrfmiddlewaretoken]')
            },
            success: searchSuccess,
            dataType: 'html'
        });
    });
});

function searchSuccess(data, textStatus, jqXHR)
{
    $('#search-results').html(data);
}