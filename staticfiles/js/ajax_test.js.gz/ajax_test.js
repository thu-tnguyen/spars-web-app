// initiate XMLHttpRequest obj to fetch/log
var request = new XMLHttpRequest();
// set request 
// two options, clicking the categories
// or typing
var searchValue = document.getElementById("searchInput").value;
request.open("");